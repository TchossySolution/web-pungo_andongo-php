<?php $this->layout('_theme') ?>

<?php $this->start('removeHeader') ?>
<?php $this->stop() ?>



<?php $this->start('removeFooter') ?>
<?php $this->stop() ?>