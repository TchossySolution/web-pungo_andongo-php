 <?php $this->layout('_theme') ?>

 <section>
   <br>
   <h2>Tens que criar um arquivo para cada pagina</h2>
   <h2>Na pasta src:</h3>
     <u>
       <li> <strong>styles:</strong> nomedapaginaStyles.css</li>
       <li> <strong>js:</strong> nomedapaginaScript.js</li>
     </u>
     <br>
 </section>