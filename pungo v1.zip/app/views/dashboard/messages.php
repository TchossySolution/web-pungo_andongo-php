<?php $this->layout('_theme') ?>

<link rel="stylesheet" href="<?=urlProject(FOLDER_BASE . "/src/styles/newsStyles.css")?>">

<div>
  <h2>messages</h2>
</div>