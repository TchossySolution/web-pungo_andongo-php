function alerta() {
  alert('Clicou, homeScript 1')
}
