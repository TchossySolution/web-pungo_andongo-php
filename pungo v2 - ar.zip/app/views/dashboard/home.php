<?php $this->layout('_theme') ?>

<link rel="stylesheet" href="<?=urlProject(FOLDER_BASE . "/src/styles/homeStyles.css")?>">

<div>
  <h2>Home</h2>
</div>